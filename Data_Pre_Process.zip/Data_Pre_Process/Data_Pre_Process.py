""" Finding total null values of the given dataset """
null_value_count = file.isnull().sum().sum()
print(null_value_count)


""" Finding column-wise null values of the given dataset """
null_value_count = file.isnull().sum()
print(null_value_count)


""" Finding nan values in column from the given dataset """
finding_nan_column = df['Embarked'].isna()
print(finding_nan_column)


""" ffill() will take the data from the previous cell and bfill will take data from next fill """
df["Embarked"] = df['Embarked'].ffill()
df["Embarked"] = df['Embarked'].bfill()
print(df)


""" Find and remove the Duplicated rows in the dataset """
finding_duplicate = df.duplicated()
df_remove_duplicate = df.drop_duplicates()
print(df_remove_duplicate)


""" Filling Null values with SimpleImputer if column has categorical values"""
simple_imputer_object = SimpleImputer(strategy="most_frequent")
df["Embarked"] = simple_imputer_object.fit_transform(df[["Embarked"]])


""" Filling Null values with SimpleImputer if column has numerical values"""
simple_imputer_object = SimpleImputer(strategy="mean")
df["Age"] = simple_imputer_object.fit_transform(df[["Age"]])


""" Label encoder – converting categorical data into numerical data """
label_encoding_object = LabelEncoder()
df['Embarked'] = label_encoding_object.fit_transform(df['Embarked'])
print(df)


""" Standard Scaler - used to normalize data by rescaling the values between -1 to +1 """
standard_scaler_object = StandardScaler()
df["Fare"] = standard_scaler_object.fit_transform(df[["Fare"]])


""" MinMaxScaler -  used to normalize data by rescaling the values between 0 to +1 """
min_max_object = MinMaxScaler()
df["Fare"] = min_max_object.fit_transform(df["Fare"])

