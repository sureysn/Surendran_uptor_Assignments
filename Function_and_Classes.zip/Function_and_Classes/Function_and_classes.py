""" Functions """

print("\nDefining Functions:")
def technology(tech_name):
    return f"Technology: {tech_name}"
print(technology("Python"))

def addition(x,y):
    return x+y
result = addition(120,80)
print("sum of numbers:", result)



""" Classes """

class Person:
    def __init__(self, name, mail, location):
        self.name = name
        self.mail = mail
        self.location = location

    def details(self):
        print("Name:{}\nMail:{}\nLocation:{}".format(self.name,self.mail,self.location))

p1 = Person("Ram","Ram@xyz.com","Chennai")
print("\nDefining Classes:")
p1.details()
