import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

df = pd.read_csv("weatherAUS.csv")
print(df.head())

print("\n\nDataset Information:")
df.info()

print("\nDataset null values:")
print(df.isnull().sum())

fill_null = SimpleImputer(strategy= "mean")
df['MinTemp'] = fill_null.fit_transform(df[['MinTemp']])
df['MaxTemp'] = fill_null.fit_transform(df[['MaxTemp']])
# find_null = df['MinTemp'].isnull().sum()
# print(find_null)

fill_str = SimpleImputer(strategy= "most_frequent")
df[['RainTomorrow']] = fill_str.fit_transform(df[['RainTomorrow']])
# find_str = df['RainTomorrow'].isnull().sum()
# print(find_str)

x = df[['MinTemp','MaxTemp']]
y = df['RainTomorrow']

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2 , random_state=42)

model = LogisticRegression()
model.fit(x_train,y_train)

prediction = model.predict(x_test)

accuracy = accuracy_score(y_test,prediction)
print("\nAccuracy:", accuracy)


