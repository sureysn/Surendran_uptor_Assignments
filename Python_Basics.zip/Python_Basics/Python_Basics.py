""" Assigning numerical value to x and y variables """
x = 3
y = 4
print("Sum of x and y =", x+y)


""" Assigning string value to a and b variables """
a = "Data science"
b = "Python"
print("\nThe string value for a is:", a)
print("The string value for b is:",b)


""" For loop statement """
print("\nList of numbers:")
for i in range(5):
    print(i)    # prints the value from 0 to 4

technology = ['Python', 'SQL', 'Machine learning']
print("\nTechnologies:")
for tech in technology:
    print(tech)