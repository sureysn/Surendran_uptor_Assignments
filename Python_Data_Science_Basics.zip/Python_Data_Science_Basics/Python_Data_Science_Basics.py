import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

df = pd.read_csv("insurance.csv")
print(df.head())

""" Statistical information about the dataset """
print("\nStatistical information:\n", df.describe())

""" To know the no. of columns in dataset in detail like column name, datatype """
print("\n\nDataset Information:")
df.info()

""" To know the total number of rows and columns in the dataset """
print("\nTotal number of rows and columns:", df.shape)

""" Finding null values in the dataset """
print("\nDataset null values:")
print(df.isnull().sum().sum())

""" Finding unique values in categorical columns """
col_data = ['sex', 'smoker', 'region']
unique_values = df[col_data].apply(lambda colm: colm.unique())
print("\nNumber of unique values in the column:")
print(unique_values)

""" Converting Categorical column into numerical values """
lb = LabelEncoder()
col_encode = ['sex', 'smoker', 'region']
for col in col_encode:
    df[col] = lb.fit_transform(df[col])


""" Assigning feature variable to x and y """
x = df.drop(['charges'], axis=1)
y = df['charges']

""" Splitting the dataset for training and testing """
X_train, X_test, y_train, y_test = train_test_split(x, y, train_size=0.7 , random_state=42)

""" Predicting the data using the model """
lr = LinearRegression()
lr.fit(X_train, y_train)
y_pred = lr.predict(X_test)


""" Evaluate the performance of the model """
model_accuracy = r2_score(y_test, y_pred)
print("\nAccuracy:", model_accuracy)