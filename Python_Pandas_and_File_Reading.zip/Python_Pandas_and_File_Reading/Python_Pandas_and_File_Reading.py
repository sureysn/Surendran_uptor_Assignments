import pandas as pd

"""syntax for reading all the rows of the given csv file"""
pd.set_option("display.max_rows",None)
pd.set_option("display.max_columns",None)

"""syntax for reading a csv from current folder"""
df = pd.read_csv("diet_recommendation.csv")
print(df.head())      # By default, it shows first 5 rows from the dataset

"""syntax for reading a csv from other folder"""
df1 = pd.read_csv(r"C:\Users\hp\Downloads\diet_recommendation.csv")
print(df1.head())

"""reading first 10 data or 10 rows"""
df = pd.read_csv("diet_recommendation.csv")
print(df.head(10))

""" To read only column names of the given dataset"""
df_column_names = df.columns
print(df_column_names)

""" To read a column based data"""
column_data = df["Preferred_Cuisine"]
print(column_data)

"""reading more than one column data"""
column_data = df[["Preferred_Cuisine","Allergies"]]
print(column_data)

""" Reading rows of data """
row_data = df[0:5] #it will print 0th row to 4th row (that means total of 5 rows)
print(row_data)

row_data = df.loc[0:5] #it will print 0th row to 5th row (that means total of 6 rows)
print(row_data)

"""reading row and columns in combination"""
row_data = df.loc[0:5,"Preferred_Cuisine"] #it will print 0th row to 5th row (that means total of 6 rows) for the Preferred_Cuisine column
print(row_data)

row_data = df.loc[0:5,["Preferred_Cuisine","Allergies"]] #it will print 0th row to 5th row for the two columns (that means total of 6 rows)
print(row_data)

row_data = df.iloc[0:5,1] #it will print 0th row to 4th row of second column (that means total of 5 rows)
print(row_data)

row_data = df.iloc[0:5,0:5] #it will print 0th row to 4th row of first 5 columns (that means total of 5 rows)
print(row_data)

"""syntax for reading a excel file from current folder"""
df_excel = pd.read_excel("diet_recommendation.xlsx")
print(df_excel.head())

