import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

df = pd.read_csv("insurance.csv")
print(df.head())

""" Statistical information about the dataset """
print("\nStatistical information:\n", df.describe())

""" To know the no. of columns in dataset in detail like column name, datatype """
print("\n\nDataset Information:")
df.info()

""" To know the total number of rows and columns in the dataset """
print("\nTotal number of rows and columns:", df.shape)

""" Finding null values in the dataset """
print("\nDataset null values:")
print(df.isnull().sum().sum())


"""--------------------------------Visualization-----------------------------------"""

""" Box plot """
gender_smoke = df[df['smoker'] == 'yes']
plt.figure(figsize=(8, 6))
sns.boxplot(x = gender_smoke['region'], y = gender_smoke['age'], data=df)
plt.title('Distribution of Age by Region')
plt.xlabel('Region')
plt.ylabel('Age')
plt.show()

""" Count plot """
plt.figure(figsize=(8, 6))
sns.countplot(x = gender_smoke['sex'], data=df, )
plt.title('Smokers count by Gender')
plt.xlabel('Gender')
plt.ylabel('Count')
plt.show()

""" Scatter plot """
m = df[df['sex'] == 'male']
f = df[df['sex'] == 'female']
plt.figure(figsize=(8, 6))
plt.scatter(x = m['age'], y = m['charges'], color='darkblue', marker="*", alpha=0.6, label='Male')
plt.scatter(x = f['age'], y = f['charges'], color='pink', marker="o", alpha=0.8, label='Female')
plt.xlabel('Age')
plt.ylabel('Premium')
plt.title('Age vs Premium charges (Grouped by Gender)')
plt.legend()
plt.grid(True, alpha=0.1)
plt.show()

""" Converting Categorical column into numerical values """
lb = LabelEncoder()
col_encode = ['sex', 'smoker', 'region']
for col in col_encode:
    df[col] = lb.fit_transform(df[col])

""" Create a correlation heatmap """
plt.figure(figsize=(9, 7))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Feature Correlations')
plt.show()

# """ Assigning feature variable to x and y """
# x = df.drop(['charges'], axis=1)
# y = df['charges']
#
# """ Splitting the dataset for training and testing """
# X_train, X_test, y_train, y_test = train_test_split(x, y, train_size=0.7 , random_state=42)
#
# """ Predicting the data using the model """
# lr = LinearRegression()
# lr.fit(X_train, y_train)
# y_pred = lr.predict(X_test)
#
#
# """ Evaluate the performance of the model """
# model_accuracy = r2_score(y_test, y_pred)
# print("\nAccuracy:", model_accuracy)