import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, classification_report

df = pd.read_csv("Drug_Classification.csv")
print(df.head())

""" Statistical information about the dataset """
print("\nStatistical information:\n", df.describe())

""" To know the no. of columns in dataset in detail like column name, datatype """
print("\n\nDataset Information:")
df.info()

""" To know the total number of rows and columns in the dataset """
print("\nTotal number of rows and columns:", df.shape)

""" Finding null values in the dataset """
print("\nDataset null values:")
print(df.isnull().sum().sum())

""" Count plot """
plt.figure(figsize=(8, 6))
sns.countplot(x = df['Drug'], data=df,  palette='Set1')
plt.title('Drug Count')
plt.xlabel('Drug')
plt.ylabel('Count')
plt.show()

""" Pair plot """
sns.pairplot(df, hue='Drug', diag_kind='kde', palette='husl')
plt.show()

""" Bar plot """
plt.figure(figsize=(8, 6))
sns.barplot(x='Drug', y='Na_to_K', data=df, palette='coolwarm')
plt.title('Na-to-K Ratio Across Drug Types')
plt.xlabel('Drug Category')
plt.ylabel('Na-to-K Ratio')
plt.show()


""" Converting Categorical features into numerical values """
lb = LabelEncoder()
col_encode = ['Sex', 'BP', 'Cholesterol', 'Drug']
for col in col_encode:
    df[col] = lb.fit_transform(df[col])

""" Create a correlation heatmap """
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title('Feature Correlation Heatmap')
plt.show()


""" Assigning feature variable to x and y """
x = df.drop(['Drug'], axis=1)
y = df['Drug']

""" Splitting the dataset for training and testing """
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.7 , random_state=42)

""" Predicting the data using the model """
param_grid = {'max_depth':[None,2,3,5,10], 'criterion':["gini", 'entropy']}
model = DecisionTreeClassifier(random_state=42)
grid_search = GridSearchCV(model, param_grid)
grid_search.fit(x_train, y_train)

print("Best parameters:", grid_search.best_params_)
print("Best score:", grid_search.best_score_)

""" Evaluate the performance of the model """
predictions = grid_search.predict(x_test)
print("Accuracy:", accuracy_score(y_test, predictions))
print("Classification Report:\n", classification_report(y_test, predictions))